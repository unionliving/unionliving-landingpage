import { useEffect, useState } from 'react'
import { Shield, Clock, MapPin, Check, X } from 'lucide-react'
import { activeProduct } from '../data/PropertyList.js'

function EnquiryModal() {
  const [open, setOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    college: '',
    location: '',
    budget: ''
  })

  useEffect(() => {
    const handler = () => setOpen(true)
    window.addEventListener('open-enquiry-modal', handler)
    return () => window.removeEventListener('open-enquiry-modal', handler)
  }, [])

  useEffect(() => {
    const onEsc = (e) => {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('keydown', onEsc)
    return () => document.removeEventListener('keydown', onEsc)
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!/^\d{10}$/.test(formData.phone)) {
      alert('Please enter a valid 10-digit phone number.')
      return
    }

    setIsSubmitting(true)

    try {
      const accessKey = import.meta.env.VITE_LEADSQUARED_ACCESS_KEY
      const secretKey = import.meta.env.VITE_LEADSQUARED_SECRET_KEY
      if (!accessKey || !secretKey) {
        alert('Missing LeadSquared API keys. Please configure environment variables.')
        return
      }
      const apiUrl = `https://api-in21.leadsquared.com/v2/LeadManagement.svc/Lead.CreateOrUpdate?postUpdatedLead=false&accessKey=${encodeURIComponent(accessKey)}&secretKey=${encodeURIComponent(secretKey)}`
      const payload = [
        { Attribute: 'FirstName', Value: formData.name },
        { Attribute: 'Phone', Value: formData.phone },
        { Attribute: 'EmailAddress', Value: formData.email },
        { Attribute: 'mx_College_or_Company_Name', Value: formData.college },
        { Attribute: 'mx_Preferred_Location', Value: formData.location },
        { Attribute: 'mx_Monthly_Budget', Value: formData.budget },
        { Attribute: 'source', Value: 'Ruturaj Landing Page' },
        { Attribute: 'SearchBy', Value: 'Phone' }
      ]

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      const rawBody = await response.text()
      let result = null
      try {
        result = rawBody ? JSON.parse(rawBody) : null
      } catch {
        result = null
      }

      if (response.ok && result?.Status === 'Success') {
        if (result?.Message) {
          console.log('Lead Created/Updated:', {
            Id: result.Message.Id,
            RelatedId: result.Message.RelatedId,
            IsCreated: result.Message.IsCreated
          })
        }
        if (window.fbq) window.fbq('track', 'Form_Submit')
        if (window.gtag) window.gtag('event', 'conversion', {
          send_to: 'AW-11425120901/6RJQCPGuuvsbEIWF9scq',
          value: 1.0,
          currency: 'INR',
        })
        window.dispatchEvent(new CustomEvent('open-thankyou-modal'))
        setOpen(false)
        setSubmitted(false)
        setFormData({
          name: '',
          phone: '',
          email: '',
          college: '',
          location: '',
          budget: ''
        })
      } else {
        console.error('LeadSquared API Error:', result?.ExceptionMessage || result || rawBody)
        alert('Submission failed: ' + (result?.ExceptionMessage || response.statusText || 'Unknown error'))
      }
    } catch (error) {
      console.error('Submission failed:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const trustBullets = [
    { icon: Shield, text: 'Verified Properties' },
    { icon: Clock, text: '24/7 Support' },
    { icon: MapPin, text: 'Prime Locations' }
  ]

  const colleges = [
    'Select your college',
    'Delhi University',
    'IP University',
    'Amity University',
    'Sharda University',
    'Jaypee Institute',
    'Other'
  ]

  const locations = ['Select preferred location', ...Array.from(new Set(activeProduct.map(p => p.location).filter(Boolean)))]

  const budgets = [
    'Select your budget',
    'Under ₹10,000',
    '₹10,000 - ₹15,000',
    '₹15,000 - ₹20,000',
    '₹20,000 - ₹25,000',
    'Above ₹25,000'
  ]

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[60]" role="dialog" aria-modal="true">
      <div onClick={() => setOpen(false)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="absolute inset-0 flex items-end md:items-center justify-center p-3 md:p-4 overscroll-contain">
        <div className="w-full max-w-md md:max-w-xl bg-white rounded-2xl shadow-2xl p-5 md:p-8 relative max-h-[88vh] overflow-y-auto">
          <button onClick={() => setOpen(false)} className="absolute top-3 right-3 text-gray-500 hover:text-gray-700">
            <X className="w-5 h-5" />
          </button>

          <div className="text-center mb-5 md:mb-6">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-1 md:mb-2">Get Free Consultation</h2>
            <p className="text-gray-500 text-sm">Fill the form and our expert will call you within 2 hours</p>
          </div>

          {!submitted ? (
            <>
              <div className="flex flex-wrap gap-2 mb-5 md:mb-6">
                {trustBullets.map((bullet, i) => (
                  <div key={i} className="flex items-center gap-2 bg-gray-50 px-3 py-2 rounded-lg">
                    <bullet.icon className="w-4 h-4 text-[#FC7451]" />
                    <span className="text-sm text-gray-700">{bullet.text}</span>
                  </div>
                ))}
              </div>

              <form onSubmit={handleSubmit} className="space-y-3 md:space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter your full name"
                    required
                    className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-3 md:gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+91 98765 43210"
                      required
                      className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your@email.com"
                      required
                      className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Your College/University *</label>
                  <input
                    type="text"
                    name="college"
                    value={formData.college}
                    onChange={handleChange}
                    placeholder="Enter your college or university"
                    required
                    className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-3 md:gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Location *</label>
                    <select
                      name="location"
                      value={formData.location}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all bg-white"
                    >
                      {locations.map((location, index) => (
                        <option key={index} value={index === 0 ? '' : location}>
                          {location}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Budget *</label>
                    <select
                      name="budget"
                      value={formData.budget}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all bg-white"
                    >
                      <option value="">Select your budget</option>
                      <option value="10000">Under ₹10,000</option>
                      <option value="10000">₹10,000 - ₹15,000</option>
                      <option value="15000">₹15,000 - ₹20,000</option>
                      <option value="20000">₹20,000 - ₹25,000</option>
                      <option value="25000">Above ₹25,000</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 md:py-4 bg-[#D64C27] text-white font-semibold rounded-xl transition-all duration-300 shadow-lg disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Check className="w-5 h-5" />
                      Get Free Consultation
                    </>
                  )}
                </button>
              </form>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="mx-auto w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-3">
                <Check className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-lg font-semibold text-gray-900">Enquiry submitted</p>
              <p className="text-sm text-gray-500 mt-1">Our team will reach out shortly</p>
              <button onClick={() => { setOpen(false); setSubmitted(false) }} className="mt-6 w-full py-3 bg-[#D64C27] text-white rounded-xl">
                Close
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default EnquiryModal
